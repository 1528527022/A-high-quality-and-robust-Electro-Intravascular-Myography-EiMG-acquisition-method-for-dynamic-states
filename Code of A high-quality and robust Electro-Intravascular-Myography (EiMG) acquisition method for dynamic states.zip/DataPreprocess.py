"""
1_DataPreprocess.py: To preprocess the acquired EiMG and sEMG data, including band-pass filter, notch filter,
                     wavelet filter and MVC normalization. The "i" and "s" in the code generally refer to "EiMG" and "sEMG"
15285
2025/7/30
"""
import os
import datetime
import openpyxl
from scipy import signal
import re
import numpy as np
import h5py
import pywt
import pandas as pd


def calculate_mvc_for_three_days(root_path, day_list, EiMG_column, sEMG_column, save_path, mvc_window_sec, sample_rate):

    def compute_max_rms(signal, window_samples):
        max_rms = 0
        for i in range(0, len(signal) - window_samples + 1, window_samples):
            win = signal[i:i + window_samples]
            rms = np.sqrt(np.mean(win ** 2))
            if rms > max_rms:
                max_rms = rms
        return max_rms

    all_EiMG = []
    all_sEMG = []
    window_samples = int(mvc_window_sec * sample_rate)

    for day in day_list:
        folder = os.path.join(root_path, day)
        if not os.path.exists(folder):
            print(f"[Warning] Skip the non-existent date directory: {folder}")
            continue
        # 获取所有组
        group_folders = sorted(
            [f for f in os.listdir(folder) if os.path.isdir(os.path.join(folder, f))],
            key=lambda x: int(''.join(filter(str.isdigit, x))) if any(c.isdigit() for c in x) else 0
        )
        for group in group_folders:
            group_path = os.path.join(folder, group)
            try:
                raw_i = all_data(group_path, EiMG_column)
                raw_s = all_data(group_path, sEMG_column)
                all_EiMG.append(raw_i)
                all_sEMG.append(raw_s)
            except Exception as e:
                print(f"[Warning] the {group_path} is abnormal: {e}")

    # 合并为1D数组
    all_EiMG = np.concatenate(all_EiMG) if all_EiMG else np.array([])
    all_sEMG = np.concatenate(all_sEMG) if all_sEMG else np.array([])

    if len(all_EiMG) == 0 or len(all_sEMG) == 0:
        print("No valid EMG data was found, so the MVC could not be calculated")
        return 1.0, 1.0  # 默认返回1防止后续出错

    mvc_i = compute_max_rms(all_EiMG, window_samples)
    mvc_s = compute_max_rms(all_sEMG, window_samples)
    print(f"global MVC: EiMG = {mvc_i:.4f}, sEMG = {mvc_s:.4f}")

    # 可保存为csv
    if save_path:
        mvc_df = pd.DataFrame({'Type': ['EiMG', 'sEMG'], 'MVC_Value': [mvc_i, mvc_s]})
        mvc_df.to_csv(os.path.join(save_path, 'mvc_values.csv'), index=False)
        print(f"MVC is saved to: {os.path.join(save_path, 'mvc_values.csv')}")

    return mvc_i, mvc_s


def adaptive_notch_filter(data, fs, base_freq=50, harmonics=3, Q=30):

    nyq = fs / 2
    filtered = data.copy()

    for n in range(1, harmonics + 1):
        f0 = base_freq * n
        if f0 > nyq * 0.9:
            break

        adj_Q = Q * (1 + 0.1 * (n - 1))

        b, a = signal.iirnotch(f0, adj_Q, fs)
        filtered = signal.filtfilt(b, a, filtered)

    return filtered


def butter_bandpass_filter(data, lowcut, highcut, fs, order):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = signal.butter(order, [low, high], btype='band')
    filtered_data = signal.filtfilt(b, a, data)
    return filtered_data


def filtering(data, lowcut, highcut, fs, order):
    data1 = butter_bandpass_filter(data, lowcut, highcut, fs, order)
    data2 = adaptive_notch_filter(data1, fs, 50, harmonics=3, Q=30)
    filter_data = np.array(data2)
    return filter_data


def wavelet_denoise(data, wavelet='db4', level=4, threshold_ratio=0.04):
    """
    对1维信号进行小波去噪处理
    """
    coeffs = pywt.wavedec(data, wavelet, level=level)

    coeffs[1:] = [
        pywt.threshold(c, threshold_ratio * np.max(c), mode='soft')
        for c in coeffs[1:]
    ]
    return pywt.waverec(coeffs, wavelet)[:len(data)]


def emg_timeseries(o_data_i, o_data_s):
    data_i = wavelet_denoise(o_data_i)
    data_s = wavelet_denoise(o_data_s)

    if data_s is not None and len(data_i) != len(data_s):
        print(f"警告：主信号长度 {len(data_i)} ≠ 参考信号 {len(data_s)}，将统一截取到最小长度")
        min_len = min(len(data_i), len(data_s))
        data_i = data_i[:min_len]
        data_s = data_s[:min_len]

    return data_i, data_s


def all_data(root_folder, column):
    """将一组数据的所有xlsx文件按数字顺序拼接成一维数组"""
    # Obtain all xlsx files in the folder and sort them by number
    file_names = sorted(
        [f for f in os.listdir(root_folder) if f.endswith('.xlsx')],
        key=lambda x: int(re.findall(r'\d+', x)[0]) if re.findall(r'\d+', x) else 0
    )

    dataframe = []
    for file_name in file_names:
        file_path = os.path.join(root_folder, file_name)
        try:
            workbook = openpyxl.load_workbook(file_path)
            sheet = workbook.active

            data = []
            for cell in sheet[column]:

                if isinstance(cell.value, datetime.datetime):

                    data.append(0)
                elif cell.value is None:

                    data.append(0)
                else:
                    try:

                        data.append(float(cell.value))
                    except (ValueError, TypeError):

                        data.append(0)

            dataframe.append(data)
        except Exception as e:
            print(f"reading {file_name} failed: {str(e)}")
            dataframe.append([0] * len(sheet[column]))

    return np.concatenate(dataframe) if dataframe else np.array([])


def design_filter(fs, low, high, order, filter_type='bandpass'):
    nyq = 0.5 * fs
    low_norm = low / nyq if low else None
    high_norm = high / nyq if high else None

    if filter_type == 'bandpass':
        b, a = signal.butter(order, [low_norm, high_norm], btype='bandpass')
    elif filter_type == 'notch':
        b, a = signal.butter(order, [notch_freq - 2, notch_freq + 2], fs=fs, btype='bandstop')
    return b, a


def apply_filter(data, b, a):
    return signal.filtfilt(b, a, data)


def preprocess_emg_data(root_path, day_list, EiMG_column, sEMG_column, state, save_path, mvc_csv_path):

    import os
    import numpy as np
    import pandas as pd

    os.makedirs(save_path, exist_ok=True)

    # read global MVC
    mvc_df = pd.read_csv(mvc_csv_path)
    mvc_i = float(mvc_df.loc[mvc_df['Type'] == 'EiMG', 'MVC_Value'].values[0])
    mvc_s = float(mvc_df.loc[mvc_df['Type'] == 'sEMG', 'MVC_Value'].values[0])
    print(f"EiMG MVC={mvc_i:.4f}, sEMG MVC={mvc_s:.4f}")

    # filter design
    b_band, a_band = design_filter(fs, low_cut, high_cut, order, 'bandpass')
    b_notch, a_notch = design_filter(fs, notch_freq - 2, notch_freq + 2, notch_freq, 'notch')

    for day in day_list:
        all_EiMG = []
        all_sEMG = []
        group_boundaries = []
        total_length = 0

        day_path = os.path.join(root_path, day)
        if not os.path.exists(day_path):
            print(f"[Warning] Skip the non-existent date directory: {day_path}")
            continue
        group_folders = sorted(
            [f for f in os.listdir(day_path) if os.path.isdir(os.path.join(day_path, f))],
            key=lambda x: int(''.join(filter(str.isdigit, x))) if any(c.isdigit() for c in x) else 0
        )
        for folder_name in group_folders:
            folder_path = os.path.join(day_path, folder_name)
            try:
                raw_EiMG = all_data(folder_path, EiMG_column)
                raw_sEMG = all_data(folder_path, sEMG_column)

                if len(raw_EiMG) == 0 or len(raw_sEMG) == 0:
                    continue

                filtered_EiMG = apply_filter(apply_filter(raw_EiMG, b_band, a_band), b_notch, a_notch)
                filtered_sEMG = apply_filter(apply_filter(raw_sEMG, b_band, a_band), b_notch, a_notch)

                # wavelet filter
                filtered_EiMG, filtered_sEMG = emg_timeseries(filtered_EiMG, filtered_sEMG)

                # ---- MVC Normalization----
                norm_EiMG = filtered_EiMG / mvc_i
                norm_sEMG = filtered_sEMG / mvc_s

                start_idx = total_length
                end_idx = total_length + len(norm_EiMG)
                group_boundaries.append((f"{day}_{folder_name}", start_idx, end_idx))

                boundary_length = int(fs * window_size)
                boundary = np.full(boundary_length, np.nan)
                total_length = end_idx + boundary_length

                all_EiMG.append(np.concatenate([norm_EiMG, boundary]))
                all_sEMG.append(np.concatenate([norm_sEMG, boundary]))

            except Exception as e:
                import traceback
                print(f"[Error] the {folder_path} is abnormal：{e}")
                traceback.print_exc()
                continue

        if not all_EiMG:
            print(f"Warning: {day} No valid data was found!")
            continue

        # concatenate all data of some day
        full_EiMG = np.concatenate(all_EiMG)
        full_sEMG = np.concatenate(all_sEMG)

        rows = []
        for name, s_idx, e_idx in group_boundaries:
            idxs = np.arange(s_idx, e_idx)
            for idx in idxs:
                rows.append((idx, full_EiMG[idx], 'EiMG', name))
                rows.append((idx, full_sEMG[idx], 'sEMG', name))
            for idx in range(e_idx, e_idx + int(fs * window_size)):
                rows.append((idx, np.nan, 'EiMG', name))
                rows.append((idx, np.nan, 'sEMG', name))

        df = pd.DataFrame(rows, columns=['Index', 'Value', 'Type', 'Group'])

        # save data
        out_path = os.path.join(save_path, f'EMG_Preprocessed_{day}_{state}.csv')
        df.to_csv(out_path, index=False)
        print(f"{day} preprocessed data saved: {out_path}")

        # save boundaries of groups
        boundary_path = os.path.join(save_path, f'EMG_Boundaries_{day}_{state}.csv')
        pd.DataFrame(group_boundaries, columns=['Group', 'Start', 'End']).to_csv(boundary_path, index=False)
        print(f"{day} boundaries saved: {boundary_path}")

# Parameter
low_cut = 10
high_cut = 120
fs = 256
order = 4
notch_freq = 50
window_size = 0.5
step_size = window_size
EiMG_column = 'B'
sEMG_column = 'C'
dates = ['Day 1', 'Day 2', 'Day 3']
statew = 'Walk'
states = 'Stand'
state = statew
root_path = r'my_root_path'
mvc_csv_path = r'mvc_save_path'
save_path = r'data_after_mvc_path'

if __name__ == '__main__':

    # calculate mvc
    calculate_mvc_for_three_days(root_path, dates, EiMG_column, sEMG_column, save_path, mvc_window_sec=window_size, sample_rate=fs)
    mvc_csv_path = os.path.join(save_path, 'mvc_values.csv')
    # do the filtering, MVC normalization and data saving
    preprocess_emg_data(root_path, dates, EiMG_column, sEMG_column, state, save_path, mvc_csv_path)

