README
项目名称
A high-quality and robust Electro-Intravascular-Myography (EiMG) acquisition method for dynamic states

项目简介
本项目包含一套用于分析**介入式肌电（EiMG）与表面肌电（sEMG）**信号的Python代码。可用于动态（行走、运动）与静态（站立、静止）状态下多种特征的批量处理、分析与可视化，包括信号预处理、时域/频域特征提取、滑窗分析、聚类、能量分析等。

本代码适用于生物电信号研究、肌电数据挖掘、医疗工程、机器学习等应用场景。

主要功能
批量读取与拼接多天多状态下的EiMG/sEMG信号

信号预处理（滤波、标准化等）

时域分析（如RMS、MAV、峰度、KR等）

频域分析（PSD功率谱、多频段能量与能量占比计算）

滑动窗口特征分析于聚类分析

肌电信号之间的相关性


文件结构
（待补充）：

yaml

├── src/                    # 源码目录
│   ├── load_and_concatenate_emg.py    # 读取与拼接数据
│   ├── feature_extraction.py          # 特征提取函数
│   ├── psd_band_ratio_analysis.py     # 频域特征分析
│   ├── ...
├── data/                   # 数据目录（建议结构为 data/状态/日期/文件）
│   ├── Steady/
│   │   ├── 0918/0918_i.xlsx
│   │   └── ...
│   └── Walk/
│       └── 0920/0920_s.xlsx
├── results/                # 分析结果输出目录
│   ├── features/
│   ├── plots/
│   └── ...
├── requirements.txt        # Python依赖库
├── README.md
依赖环境
Python >= 3.7

pandas

numpy

scipy

matplotlib

openpyxl

tqdm

运行方法
准备数据
将肌电数据（EiMG、sEMG）以 .xlsx 格式放入指定的data/目录下，目录结构建议为：
状态/日期_i.xlsx 和 日期_s.xlsx。

查看结果
分析结果会自动保存在results/文件夹下。

注意事项
数据文件需为 .xlsx 格式，且每个文件首列为信号数据。

各特征分析函数参数请参考对应.py文件头部的docstring说明。

如有自定义信号特征或分组需求，可在相应脚本基础上修改。

联系方式
如有问题请联系项目负责人：

姓名：Ying Du

邮箱：2120230491@nankai.edu.cn

致谢
感谢实验团队及数据支持。