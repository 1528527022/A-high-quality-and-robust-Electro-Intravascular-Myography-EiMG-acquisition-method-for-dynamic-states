"""
2_TimeNFrequencyDomain.py: To extract the utilized time and frequency domain features. The "i" and "s" in the code generally refer to "EiMG" and "sEMG"
15285
2025/7/30
"""
from matplotlib import pyplot as plt
from scipy.ndimage import gaussian_filter1d
from scipy.signal import welch, stft
from tqdm import tqdm
import os
import pandas as pd
import numpy as np
from scipy.stats import kurtosis
from typing import List, Tuple, Dict

def compute_rms(signal):
    return np.sqrt(np.mean(signal ** 2))


def compute_mav(signal):
    return np.mean(np.abs(signal))


def extract_emg_time_features(date, file_path, save_path):  # 提取肌电的时域特征

    preprocessed_csv = os.path.join(file_path, f'EMG_Preprocessed_{date}_{state}.csv')
    df = pd.read_csv(preprocessed_csv)
    boundaries_csv = os.path.join(file_path, f'EMG_Boundaries_{date}_{state}.csv')
    boundaries = pd.read_csv(boundaries_csv)
    sample_rate = fs

    full_EiMG = df[df['Type'] == 'EiMG'].sort_values('Index')['Value'].values
    full_sEMG = df[df['Type'] == 'sEMG'].sort_values('Index')['Value'].values

    group_boundaries = list(zip(boundaries['Group'], boundaries['Start'], boundaries['End']))

    window_samples = int(window_size * sample_rate)
    step_samples = int(step_size * sample_rate)
    num_windows = (len(full_EiMG) - window_samples) // step_samples + 1

    features = {
        'Group': [], 'Time': [],
        'EiMG_RMS': [], 'sEMG_RMS': [],
        'EiMG_MAV': [], 'sEMG_MAV': []
    }

    valid_windows = 0

    for start in tqdm(range(0, len(full_EiMG) - window_samples, step_samples), total=num_windows):
        end = start + window_samples
        window_EiMG = full_EiMG[start:end]
        window_sEMG = full_sEMG[start:end]

        if np.isnan(window_EiMG).any() or np.isnan(window_sEMG).any():
            continue

        start_in_group = False
        for name, s_idx, e_idx in group_boundaries:
            if s_idx <= start < e_idx:
                start_in_group = True
                break

        if not start_in_group:
            continue

        current_group = next((name for name, s_idx, e_idx in group_boundaries if s_idx <= start < e_idx), "Unknown")

        # calculating
        features['Group'].append(current_group)
        features['Time'].append(start / sample_rate)
        features['EiMG_RMS'].append(compute_rms(window_EiMG))
        features['sEMG_RMS'].append(compute_rms(window_sEMG))
        features['EiMG_MAV'].append(compute_mav(window_EiMG))
        features['sEMG_MAV'].append(compute_mav(window_sEMG))
        valid_windows += 1

    feature_df = pd.DataFrame(features)

    # each group's mean of features value
    group_stats = feature_df.groupby('Group').agg(
        EiMG_RMS_Mean=('EiMG_RMS', 'mean'),
        sEMG_RMS_Mean=('sEMG_RMS', 'mean'),
        EiMG_EIMG_Mean=('EiMG_MAV', 'mean'),
        sEMG_EIMG_Mean=('sEMG_MAV', 'mean')
    ).reset_index()

    base_name = os.path.basename(preprocessed_csv).replace('Preprocessed', 'Features')
    out_path = os.path.join(save_path, base_name)
    feature_df.to_csv(out_path, index=False)
    print(f"sliding window features have been saved to: {out_path}")

    group_summary_path = os.path.join(save_path, base_name.replace('Features', 'GroupSummary'))
    group_stats.to_csv(group_summary_path, index=False)
    print(f"The group mean results have been saved to: {group_summary_path}")

    return feature_df


def kr(x):
    q_low = np.percentile(x, 2.5)
    q_high = np.percentile(x, 97.5)
    q25 = np.percentile(x, 25)
    q75 = np.percentile(x, 75)
    return (q_high - q_low) / (q75 - q25) - 2.91


def compute_kurtosis_with_sliding_window(date, file_path, output_folder, state, fs=256, win_sec=0.5, overlap_frac=0.5):
    # read data
    preprocessed_csv = os.path.join(file_path, f'EMG_Preprocessed_{date}_{state}.csv')
    boundaries_csv = os.path.join(file_path, f'EMG_Boundaries_{date}_{state}.csv')
    df = pd.read_csv(preprocessed_csv)
    boundaries = pd.read_csv(boundaries_csv)

    data_i = df[df['Type'] == 'EiMG'].sort_values('Index')['Value'].values
    data_s = df[df['Type'] == 'sEMG'].sort_values('Index')['Value'].values
    group_boundaries = list(zip(boundaries['Group'], boundaries['Start'], boundaries['End']))

    win_len = int(win_sec * fs)
    noverlap = int(win_len * overlap_frac)
    step_size = win_len - noverlap

    kurt_i = []
    kurt_s = []

    for start in range(0, len(data_i) - win_len + 1, step_size):
        # group boundaries check
        in_group = False
        for _, s_idx, e_idx in group_boundaries:
            if s_idx <= start < e_idx:
                in_group = True
                break
        if not in_group:
            continue

        win_i = data_i[start:start + win_len]
        win_s = data_s[start:start + win_len]
        kurt_i.append(kurtosis(win_i, fisher=True))
        kurt_s.append(kurtosis(win_s, fisher=True))

    df_out = pd.DataFrame({
        "Kurtosis_i": np.round(kurt_i, 4),
        "Kurtosis_s": np.round(kurt_s, 4),
        "Mean_Kurtosis_i": round(np.mean(kurt_i), 4) if len(kurt_i) > 0 else np.nan,
        "Mean_Kurtosis_s": round(np.mean(kurt_s), 4) if len(kurt_s) > 0 else np.nan
    })

    os.makedirs(output_folder, exist_ok=True)
    out_file = os.path.join(output_folder, f"{date}_{state}_Kurtosis.xlsx")
    with pd.ExcelWriter(out_file, engine='openpyxl') as writer:
        df_out.to_excel(writer, index=False)

    print(f"already save to：{out_file}")


def compute_KR_with_sliding_window(date, file_path, output_folder, state, fs=256, win_sec=0.5, overlap_frac=0.5):

    # read data
    preprocessed_csv = os.path.join(file_path, f'EMG_Preprocessed_{date}_{state}.csv')
    boundaries_csv = os.path.join(file_path, f'EMG_Boundaries_{date}_{state}.csv')
    df = pd.read_csv(preprocessed_csv)
    boundaries = pd.read_csv(boundaries_csv)

    data_i = df[df['Type'] == 'EiMG'].sort_values('Index')['Value'].values
    data_s = df[df['Type'] == 'sEMG'].sort_values('Index')['Value'].values
    group_boundaries = list(zip(boundaries['Group'], boundaries['Start'], boundaries['End']))

    win_len = int(win_sec * fs)
    noverlap = int(win_len * overlap_frac)
    step_size = win_len - noverlap

    kr2_i = []
    kr2_s = []

    for start in range(0, len(data_i) - win_len + 1, step_size):
        # group boundaries check
        in_group = False
        for _, s_idx, e_idx in group_boundaries:
            if s_idx <= start < e_idx:
                in_group = True
                break
        if not in_group:
            continue

        win_i = data_i[start:start + win_len]
        win_s = data_s[start:start + win_len]
        kr2_i.append(kr(win_i))
        kr2_s.append(kr(win_s))

    df_out = pd.DataFrame({
        "KR_i": np.round(kr2_i, 4),
        "KR_s": np.round(kr2_s, 4),
        "Mean_KR_i": round(np.mean(kr2_i), 4) if len(kr2_i) > 0 else np.nan,
        "Mean_KR_s": round(np.mean(kr2_s), 4) if len(kr2_s) > 0 else np.nan
    })

    os.makedirs(output_folder, exist_ok=True)
    out_file = os.path.join(output_folder, f"{date}_{state}_KR.xlsx")
    with pd.ExcelWriter(out_file, engine='openpyxl') as writer:
        df_out.to_excel(writer, index=False)

    print(f"already save to：{out_file}")


def analyze_emg_psd_and_band_ratio(EiMG_signal, sEMG_signal, BANDS, fs):


    def compute_psd(signal, fs, nperseg=1024):
        f, Pxx = welch(signal, fs=fs, nperseg=nperseg)
        Pxx_smooth = gaussian_filter1d(Pxx, sigma=2)
        return f, Pxx_smooth

    def compute_band_energy_ratio(f, Pxx, bands):
        band_energy = {}
        for band, (low, high) in bands.items():
            idx = (f >= low) & (f < high)
            energy = np.trapz(Pxx[idx], f[idx])
            band_energy[band] = energy
        total_energy = np.trapz(Pxx, f)
        band_ratio = {band: (energy / total_energy if total_energy > 0 else 0)
                      for band, energy in band_energy.items()}
        return band_ratio

        # 计算
        f_i, Pxx_i = compute_psd(EiMG_signal, fs)
        f_s, Pxx_s = compute_psd(sEMG_signal, fs)
        band_ratio_i = compute_band_energy_ratio(f_i, Pxx_i, BANDS)
        band_ratio_s = compute_band_energy_ratio(f_s, Pxx_s, BANDS)

        # 保存结果
        os.makedirs(save_path, exist_ok=True)
        file_path = os.path.join(save_path, f'psd_band_ratio_{state}.xlsx')
        with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
            for name, freq, psd, ratio in [
                ('EiMG', f_i, Pxx_i, band_ratio_i),
                ('sEMG', f_s, Pxx_s, band_ratio_s)
            ]:
                df_psd = pd.DataFrame({'Frequency': freq, 'PSD': psd})
                df_band = pd.DataFrame([ratio])
                df_psd.to_excel(writer, sheet_name=name, index=False)
                df_band.to_excel(writer, sheet_name=name, index=False, startrow=len(df_psd) + 2)
        print(f"[信息] PSD和能量占比结果已保存至: {file_path}")


def plot_emg_spectrograms(eimg_signal, semg_signal, fs, win_sec, overlap, vmax=None, fmax=120):

    n_total = len(eimg_signal)
    start_sample = 0
    end_sample = n_total


    seg_eimg = eimg_signal[start_sample:end_sample]
    seg_semg = semg_signal[start_sample:end_sample]

    nperseg = int(win_sec * fs)

    fig, axs = plt.subplots(2, 1, figsize=(13, 8), sharex=True)

    for idx, (signal, name, cmap) in enumerate([
        (seg_eimg, 'EiMG', 'viridis'),
        (seg_semg, 'sEMG', 'viridis')
    ]):
        seg_len = len(signal)
        cur_nperseg = min(nperseg, seg_len)
        cur_noverlap = int(cur_nperseg * overlap)
        if cur_noverlap >= cur_nperseg:
            cur_noverlap = cur_nperseg // 2

        f, t, Zxx = stft(signal, fs=fs, nperseg=cur_nperseg, noverlap=cur_noverlap)
        max_idx = np.where(f <= fmax)[0][-1] + 1
        power = np.abs(Zxx[:max_idx, :])

        im = axs[idx].imshow(
            20 * np.log10(power + 1e-6),
            aspect='auto',
            origin='lower',
            extent=[t[0] + (start_sample / fs), t[-1] + (start_sample / fs), f[0], f[max_idx - 1]],
            cmap=cmap,
            vmax=vmax
        )
        axs[idx].set_ylabel('Frequency (Hz)')
        axs[idx].set_title(f'{name} Spectrogram')
        axs[idx].set_ylim(0, fmax)
        fig.colorbar(im, ax=axs[idx], orientation='vertical', pad=0.01, label='Power (dB)')

    axs[-1].set_xlabel('Time (s)')
    plt.suptitle(f'EiMG & sEMG Spectrograms (Time {start_sample / fs:.1f}-{end_sample / fs:.1f} s)', fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.show()


def load_and_concatenate_emg_csv(date_list, state, base_path):
    all_EiMG_filtered = []
    all_sEMG_filtered = []

    for date in date_list:
        preprocessed_csv = os.path.join(base_path, f'EMG_Preprocessed_{date}_{state}.csv')
        df = pd.read_csv(preprocessed_csv)
        data_i = df[df['Type'] == 'EiMG'].sort_values('Index')['Value'].values
        data_s = df[df['Type'] == 'sEMG'].sort_values('Index')['Value'].values

        all_EiMG_filtered.append(data_i)
        all_sEMG_filtered.append(data_s)

    if len(all_EiMG_filtered) == 0 or len(all_sEMG_filtered) == 0:
        print("no valid data, return empty array")
        return np.array([]), np.array([])

    concatenated_i = np.concatenate(all_EiMG_filtered, axis=0)
    concatenated_s = np.concatenate(all_sEMG_filtered, axis=0)

    print("EiMG shape:", concatenated_i.shape)
    print("sEMG shape:", concatenated_s.shape)

    return concatenated_i, concatenated_s


def sliding_psd_bands(sig: np.ndarray, fs: float,
                      win_len: int, noverlap: int,
                      bands: Dict[str, Tuple[float, float]]
                      ) -> Dict[str, np.ndarray]:

    step = win_len - noverlap
    n_win = (len(sig) - win_len) // step + 1
    energies = {b: np.zeros(n_win, dtype=np.float64) for b in bands}

    for i in range(n_win):
        seg = sig[i*step : i*step + win_len]
        f, Pxx = welch(seg, fs=fs, window='hann', nperseg=win_len, noverlap=noverlap)
        for bname, (low, high) in bands.items():
            idx = np.logical_and(f >= low, f <= high)
            energies[bname][i] = np.trapz(Pxx[idx], f[idx])
    return energies


def sliding_cv(arr: np.ndarray, win_len: int, noverlap: int) -> np.ndarray:

    if arr is None or len(arr) < win_len:
        return np.array([], dtype=np.float64)

    step = win_len - noverlap
    n_win = (len(arr) - win_len) // step + 1
    cv_values = np.full(n_win, np.nan, dtype=np.float64)

    for i in range(n_win):
        seg = arr[i*step : i*step + win_len]
        mean_seg = np.mean(seg)
        if mean_seg == 0:
            cv_values[i] = np.nan
        else:
            cv_values[i] = np.std(seg) / mean_seg

    return cv_values


def compute_psd_cv_all_three_days(base_path, state, day_list, bands, fs, save_dir):
    """
    对三天数据分别计算PSD CV，不剔除任何区间，直接保存。
    """
    os.makedirs(save_dir, exist_ok=True)

    for date in day_list:
        preprocessed_csv = os.path.join(base_path, f'EMG_Preprocessed_{date}_{state}.csv')
        df = pd.read_csv(preprocessed_csv)
        data_i = df[df['Type'] == 'EiMG'].sort_values('Index')['Value'].values
        data_s = df[df['Type'] == 'sEMG'].sort_values('Index')['Value'].values


        # PSD CV计算
        win_len = int(0.5 * fs)
        noverlap = 0
        win_cv = 10
        nlap_cv = 0

        band_i = sliding_psd_bands(data_i, fs, win_len, noverlap, bands)
        cv_i_alpha = sliding_cv(band_i['alpha'], win_cv, nlap_cv)
        cv_i_beta = sliding_cv(band_i['beta'], win_cv, nlap_cv)
        cv_i_gamma = sliding_cv(band_i['gamma'], win_cv, nlap_cv)
        cv_i_high_gamma = sliding_cv(band_i['high_gamma'], win_cv, nlap_cv)

        band_s = sliding_psd_bands(data_s, fs, win_len, noverlap, bands)
        cv_s_alpha = sliding_cv(band_s['alpha'], win_cv, nlap_cv)
        cv_s_beta = sliding_cv(band_s['beta'], win_cv, nlap_cv)
        cv_s_gamma = sliding_cv(band_s['gamma'], win_cv, nlap_cv)
        cv_s_high_gamma = sliding_cv(band_s['high_gamma'], win_cv, nlap_cv)

        n_rows = max(len(cv_i_alpha), len(cv_i_beta), len(cv_i_gamma),
                     len(cv_s_alpha), len(cv_s_beta), len(cv_s_gamma))

        df = pd.DataFrame({
            "CV_alpha_i": list(np.round(cv_i_alpha, 4)) + [np.nan] * (n_rows - len(cv_i_alpha)),
            "CV_beta_i": list(np.round(cv_i_beta, 4)) + [np.nan] * (n_rows - len(cv_i_beta)),
            "CV_gamma_i": list(np.round(cv_i_gamma, 4)) + [np.nan] * (n_rows - len(cv_i_gamma)),
            "CV_high_gamma_i": list(np.round(cv_i_high_gamma, 4)) + [np.nan] * (n_rows - len(cv_i_high_gamma)),
            "CV_alpha_s": list(np.round(cv_s_alpha, 4)) + [np.nan] * (n_rows - len(cv_s_alpha)),
            "CV_beta_s": list(np.round(cv_s_beta, 4)) + [np.nan] * (n_rows - len(cv_s_beta)),
            "CV_gamma_s": list(np.round(cv_s_gamma, 4)) + [np.nan] * (n_rows - len(cv_s_gamma)),
            "CV_high_gamma_s": list(np.round(cv_s_high_gamma, 4)) + [np.nan] * (n_rows - len(cv_s_high_gamma)),
        })

        # 保存
        save_path = os.path.join(save_dir, f"{date}_{state}.xlsx")
        df.to_excel(save_path, index=False)
        print(f"[完成] {date} PSD CV结果已保存至: {save_path}")


fs = 256
order = 4
notch_freq = 50
window_size = 0.5
step_size = window_size
date = 'Day 1'  # you should change the date to get every day features
dates = ['Day 1', 'Day 2', 'Day 3']
statew = 'Walk'
states = 'Stand'
state = statew
data_path = r'data_after_mvc_path'
save_path = r'your save path for features'

# frequency bands
BANDS = {
    'alpha': (10, 40),
    'beta': (40, 60),
    'gamma': (60, 100),
    'high gamma': (100, 120)
}


if __name__ == "__main__":
    '''----------------------Time Domain---------------------'''
    # extract MAV and RMS
    extract_emg_time_features(date, data_path, save_path)
    # extract Kurtosis and KR
    compute_kurtosis_with_sliding_window(date, data_path, save_path, state, fs=256, win_sec=0.5, overlap_frac=0.5)
    compute_KR_with_sliding_window(date, data_path, save_path, state, fs=256, win_sec=0.5, overlap_frac=0.5)

    '''----------------------Frequency Domain---------------------'''
    # PSD and bands energy proportion
    all_EiMG, all_sEMG = load_and_concatenate_emg_csv(dates, state, data_path)
    analyze_emg_psd_and_band_ratio(all_EiMG, all_sEMG, BANDS, fs)
    # Time–frequency spectrogram of EMG signals

    # PSD CV calculating
    compute_psd_cv_all_three_days(data_path, state, dates, BANDS, fs, save_dir=save_path)
    plot_emg_spectrograms(all_EiMG, all_sEMG, fs, window_size, step_size, vmax=None, fmax=120)




