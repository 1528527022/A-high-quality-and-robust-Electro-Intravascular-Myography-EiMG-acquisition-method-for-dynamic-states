"""
3_FeatureNCorrelation.py: To obtain clustering results and correlation between EiMG and sEMG. The "i" and "s" in the code generally refer to "EiMG" and "sEMG"
15285
2025/7/30
"""

from scipy.stats import pearsonr, spearmanr, kendalltau
from sklearn.metrics.pairwise import cosine_similarity
from matplotlib.colors import LinearSegmentedColormap
import pandas as pd
import numpy as np
import os
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, accuracy_score
from scipy.stats import f_oneway, ttest_ind
from sklearn.model_selection import cross_val_predict, StratifiedKFold
import matplotlib.pyplot as plt
import seaborn as sns


def load_and_concatenate_emg_csv(date_list, state, base_path):
    all_EiMG_filtered = []
    all_sEMG_filtered = []

    for date in date_list:
        preprocessed_csv = os.path.join(base_path, f'EMG_Preprocessed_{date}_{state}.csv')
        df = pd.read_csv(preprocessed_csv)
        data_i = df[df['Type'] == 'EiMG'].sort_values('Index')['Value'].values
        data_s = df[df['Type'] == 'sEMG'].sort_values('Index')['Value'].values

        all_EiMG_filtered.append(data_i)
        all_sEMG_filtered.append(data_s)

    if len(all_EiMG_filtered) == 0 or len(all_sEMG_filtered) == 0:
        print("no valid data, return empty array")
        return np.array([]), np.array([])

    concatenated_i = np.concatenate(all_EiMG_filtered, axis=0)
    concatenated_s = np.concatenate(all_sEMG_filtered, axis=0)

    print("EiMG shape:", concatenated_i.shape)
    print("sEMG shape:", concatenated_s.shape)

    return concatenated_i, concatenated_s


def load_features(features_path):
    data, meta = [], []
    df = pd.read_excel(features_path)
    data.append(df.values)
    filename = os.path.basename(features_path).replace(".xlsx", "")
    group = 'stand' if 'Steady' in filename else 'walk'
    meta.extend([group] * len(df))
    data = np.vstack(data)
    meta = pd.DataFrame(meta, columns=['group'])
    return data, meta

def perform_clustering(X, n_clusters=2):
    model = KMeans(n_clusters=n_clusters, init='k-means++', n_init=50, max_iter=1000, random_state=42)
    return model.fit_predict(X), model


def save_results(X, clusters, model, meta, pca_data, tsne_data, pca, save_path):
    df = pd.DataFrame(X, columns=[f'Feature_{i+1}' for i in range(X.shape[1])])
    df = pd.concat([meta.reset_index(drop=True), df], axis=1)
    df['cluster'] = clusters
    df['PCA_1'] = pca_data[:, 0]
    df['PCA_2'] = pca_data[:, 1]
    df['tSNE_1'] = tsne_data[:, 0]
    df['tSNE_2'] = tsne_data[:, 1]
    df.to_excel(os.path.join(save_path, '介入聚类结果/样本级详细信息.xlsx'), index=False)

    # 聚类中心
    centers_df = pd.DataFrame(model.cluster_centers_, columns=[f'Feature_{i+1}' for i in range(X.shape[1])])
    centers_df.to_excel(os.path.join(save_path, '介入聚类结果/聚类中心.xlsx'), index_label='Cluster')

    # 聚类评估
    sil_score = silhouette_score(X, clusters)
    ch_score = calinski_harabasz_score(X, clusters)
    db_score = davies_bouldin_score(X, clusters)
    pd.DataFrame({
        'Silhouette Score': [sil_score],
        'Calinski-Harabasz Index': [ch_score],
        'Davies-Bouldin Index': [db_score]
    }).to_excel(os.path.join(save_path, '介入聚类结果/质量评估指标.xlsx'), index=False)

    # ===== 五折交叉验证的KNN混淆矩阵与准确率 =====
    true_labels = meta['group'].map({'stand': 0, 'walk': 1}).values
    knn = KNeighborsClassifier(n_neighbors=5)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    all_true = []
    all_pred = []
    acc_list = []

    for train_idx, test_idx in cv.split(X, true_labels):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = true_labels[train_idx], true_labels[test_idx]
        knn = KNeighborsClassifier(n_neighbors=5)
        knn.fit(X_train, y_train)
        y_pred = knn.predict(X_test)
        acc_list.append(accuracy_score(y_test, y_pred))
        all_true.extend(y_test)
        all_pred.extend(y_pred)

    # 计算最终整体混淆矩阵（百分比显示）
    conf_mat = confusion_matrix(all_true, all_pred)
    conf_mat_percent = conf_mat / conf_mat.sum(axis=1, keepdims=True) * 100  # 按行归一化成百分比
    df_conf = pd.DataFrame(conf_mat_percent, index=['True_Stand', 'True_Walk'], columns=['Pred_Stand', 'Pred_Walk'])
    df_conf.to_excel(os.path.join(save_path, '介入聚类结果/混淆矩阵_百分比_5折CV.xlsx'))

    # 绘制百分比热力图
    plt.figure(figsize=(5,4))
    sns.heatmap(df_conf, annot=True, fmt=".1f", cmap='Blues', cbar=True)
    plt.xlabel('Predicted label')
    plt.ylabel('True label')
    plt.title('KNN Confusion Matrix (% per row, 5-fold CV)')
    plt.tight_layout()
    plt.savefig(os.path.join(save_path, '介入聚类结果/混淆矩阵_百分比_5折CV.png'))
    plt.close()

    # 输出准确率均值和标准差
    acc_arr = np.array(acc_list)
    avg_acc = acc_arr.mean()
    std_acc = acc_arr.std()
    print("五折交叉验证平均准确率: {:.2f}% ± {:.2f}%".format(avg_acc*100, std_acc*100))
    pd.DataFrame({'Fold': list(range(1,6)), 'Accuracy': acc_arr}).to_excel(os.path.join(save_path, '介入聚类结果/每折准确率.xlsx'), index=False)
    pd.DataFrame({'Mean_Accuracy': [avg_acc], 'Std': [std_acc]}).to_excel(os.path.join(save_path, '介入聚类结果/准确率汇总.xlsx'), index=False)

    # 方差分析（前3主成分）
    pca_3 = PCA(n_components=3).fit_transform(X)
    anova = []
    for i in range(3):
        groups = [pca_3[clusters == k, i] for k in range(model.n_clusters)]
        f, p = f_oneway(*groups)
        anova.append({'PC': f'PC{i+1}', 'F': f, 'P': p})
    pd.DataFrame(anova).to_excel(os.path.join(save_path, '介入聚类结果/方差分析结果.xlsx'), index=False)

    # 主成分载荷
    loadings = pd.DataFrame(pca.components_.T,
                            columns=[f'PC{i+1}' for i in range(pca.n_components_)],
                            index=[f'Feature_{i+1}' for i in range(X.shape[1])])
    loadings.to_excel(os.path.join(save_path, '介入聚类结果/主成分载荷.xlsx'))

    # 聚类簇统计
    numeric_df = df[[f'Feature_{i+1}' for i in range(X.shape[1])] + ['cluster']]
    stats = numeric_df.groupby('cluster').agg(['mean', 'std'])
    stats.to_excel(os.path.join(save_path, '介入聚类结果/簇统计信息.xlsx'))

    # 每个簇中 stand/walk 占比统计
    group_ratio = pd.crosstab(df['cluster'], df['group'], normalize='index') * 100
    group_ratio.to_excel(os.path.join(save_path, '介入聚类结果/簇内动作类型占比.xlsx'))

    # ========== 新增：簇内统计学对比（以CV_alpha_i为例，其他可批量扩展）==========
    features_to_check = [col for col in df.columns if col.startswith('CV_') and ('_i' in col or '_s' in col)]
    stats_summary = []
    for feature in features_to_check:
        for k in sorted(df['cluster'].unique()):
            values = df[df['cluster'] == k][feature].dropna()
            stats_summary.append({
                'Feature': feature,
                'Cluster': k,
                'Mean': np.mean(values),
                'Std': np.std(values),
                'Count': len(values)
            })
        # 组间t检验
        vals_0 = df[df['cluster'] == 0][feature].dropna()
        vals_1 = df[df['cluster'] == 1][feature].dropna()
        tval, pval = ttest_ind(vals_0, vals_1, equal_var=False)
        stats_summary.append({
            'Feature': feature,
            'Cluster': 't-test',
            'Mean': tval,
            'Std': pval,
            'Count': 'p-value'
        })
    pd.DataFrame(stats_summary).to_excel(os.path.join(save_path, 'Cluster_analysis_{data_type}.xlsx'), index=False)


def compute_pearson_corr(sig1, sig2):

    corr, p_value = pearsonr(sig1, sig2)
    print(f"[Pearson] value: {corr:.4f}, p: {p_value:.4e}")
    return corr, p_value


def compute_spearman_corr(sig1, sig2):
    rho, p = spearmanr(sig1, sig2)
    print(f"[Spearman] value: {rho:.4f}, p: {p:.4e}")
    return rho, p


def kendalls_tau(x, y):

    tau, p_value = kendalltau(x, y)
    print(f'[Tau] value: {tau}, p： {p_value}')


def cosine_similarity_score(x, y):
    x = np.asarray(x).reshape(1, -1)
    y = np.asarray(y).reshape(1, -1)
    print(f'[cosine]：{cosine_similarity(x, y)[0, 0]}')


def compute_corr(data_i, data_s):
    compute_pearson_corr(data_i, data_s)
    compute_spearman_corr(data_i, data_s)
    kendalls_tau(data_i, data_s)
    cosine_similarity_score(data_i, data_s)


def segment_signal(signal, window_size=256, step_size=256):
    signal = np.asarray(signal).flatten()
    segments = []
    for start in range(0, len(signal) - window_size + 1, step_size):
        segment = signal[start:start+window_size]
        segments.append(segment)
    return np.array(segments)  # shape: [num_segments, window_size]


def compute_fft_segments(segments, fs=256):
    N = segments.shape[1]
    freq = np.fft.fftfreq(N, d=1/fs)[:N//2]
    fft_segments = np.abs(np.fft.fft(segments, axis=1))[:, :N//2]
    return freq, fft_segments  # [num_segments, N/2]


def compute_correlation_heatmap(data_i_fft, data_s_fft, method='spearman'):
    corr_matrix = np.zeros((data_i_fft.shape[1], data_s_fft.shape[1]))

    for i in range(data_i_fft.shape[1]):
        for j in range(data_s_fft.shape[1]):
            if method == 'spearman':
                corr, _ = spearmanr(data_i_fft[:, i], data_s_fft[:, j])
            elif method == 'kendall':
                corr, _ = kendalltau(data_i_fft[:, i], data_s_fft[:, j])
            else:
                raise ValueError("method must be 'spearman' or 'kendall'")
            corr_matrix[i, j] = corr

    # 1. 主对角线相关系数均值
    min_dim = min(data_i_fft.shape[1], data_s_fft.shape[1])
    diag_corrs = [corr_matrix[i, i] for i in range(min_dim)]
    diag_mean = np.mean(diag_corrs)

    # 2. 整个矩阵的最大值
    overall_max = np.max(corr_matrix)

    # 3. 整个矩阵的均值
    overall_mean = np.mean(corr_matrix)

    # 输出结果
    print(f"主对角线均值（相同频点相关性）: {diag_mean:.4f}")
    print(f"相关性矩阵最大值（最强频率对相关性）: {overall_max:.4f}")
    print(f"相关性矩阵均值（整体频率相关性）: {overall_mean:.4f}")

    return corr_matrix


def plot_heatmap(corr_matrix, freq, state, save_path, title):
    # 创建自定义 colormap：白色 -> 深蓝色
    colors = ["#FFFFFF", "#001F54"]
    custom_cmap = LinearSegmentedColormap.from_list("custom_blue", colors)

    plt.figure(figsize=(10, 8))

    # 找到freq中为整10的索引
    freq = np.asarray(freq)
    tick_idx = np.where((freq % 20 == 0))[0]
    tick_labels = [f"{int(f)}" for f in freq[tick_idx]]

    ax = sns.heatmap(
        corr_matrix,
        cmap=custom_cmap,
        center=0,
        square=True,
        cbar=True,
        cbar_kws={'shrink': 0.85}
    )

    # 只显示整20Hz的刻度和标签
    ax.set_xticks(tick_idx)
    ax.set_xticklabels(tick_labels, rotation=0, ha='center')
    ax.set_yticks(tick_idx)
    ax.set_yticklabels(tick_labels, rotation=0)

    # 坐标轴标签
    ax.set_xlabel('sEMG')
    ax.set_ylabel('EiMG')
    # ax.set_title(title, pad=15)

    # 调整colorbar字体
    cbar = ax.collections[0].colorbar
    cbar.ax.tick_params()

    plt.tight_layout()
    if save_path:
        save_as = 'svg'
        ext = save_as.lower()
        out_file = os.path.join(save_path, f"{title}_{state}.{ext}")
        plt.savefig(out_file, dpi=600, bbox_inches='tight', format=ext)
        print(f"图片已保存：{out_file}")
        plt.savefig(save_path, dpi=600)
    # plt.show()


def compute_matching_feature_correlation(data_i, data_s, feature_names, method):
    if data_i.shape != data_s.shape:
        raise ValueError("data_i and data_s must have same shape")

    n_features = data_i.shape[1]
    if feature_names is None:
        feature_names = [f"F{i + 1}" for i in range(n_features)]

    corr_vals = []
    for i in range(n_features):
        xi = data_i.iloc[:, i].values.reshape(-1, 1)
        xj = data_s.iloc[:, i].values.reshape(-1, 1)

        if method == 'spearman':
            corr, _ = spearmanr(xi.ravel(), xj.ravel())
        elif method == 'kendall':
            corr, _ = kendalltau(xi.ravel(), xj.ravel())
        elif method == 'cosine':
            corr = cosine_similarity(xi.T, xj.T)[0, 0]
        else:
            raise ValueError("method must be 'spearman', 'kendall', or 'cosine'")
        corr_vals.append(corr)

    corr_series = pd.Series(corr_vals, index=feature_names)

    # plot
    plt.figure(figsize=(16, 6))
    bars = plt.bar(corr_series.index, corr_series.values, color='#547BB4')
    plt.ylabel(f'{method.capitalize()} Correlation')
    # plt.title(f'Correlation of Matching Features between EiMG and sEMG')
    plt.xticks(rotation=90, ha='center')
    plt.tight_layout()
    plt.grid(axis='y', linestyle='--', alpha=0.6)

    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, height,
                 f'{height:.2f}', ha='center', va='bottom')

    plt.show()

    return corr_series


dates = ['Day 1', 'Day 2', 'Day 3']
statew = 'Walk'
states = 'Stand'
state = statew
data_path = r'data_after_mvc_path'
save_path = r'your save path'

feature_names = ['AFB', 'MAV', 'MAV(1)', 'MAV(2)', 'RMS', 'VAR', 'DAVR', 'SKEW', 'KURT', 'MNF', 'MDF', 'PKF', 'TTP', 'MXP', 'ApEn', 'SampEn', 'HG', 'KATZ', 'BC', 'AR(1)',
                 'AR(2)', 'AR(3)', 'AR(4)', 'DAR(1)', 'DAR(2)', 'DAR(3)', 'SSC', 'ZC', 'WL', 'SC', 'SM(1)', 'SM(2)', 'SM(3)', 'DAMV', 'DASDV', 'DPR', 'VCF', 'VFD', 'SNR', 'SMAR']


if __name__ == '__main__':
    '''----------------------Clustering and PCA analysis------------------------'''
    # read features
    path_i = os.path.join(save_path, f'features_{state}_i.xlsx')
    path_s = os.path.join(save_path, f'features_{state}_s.xlsx')
    data_i, meta_i = load_features(path_i)
    data_s, meta_s = load_features(path_s)
    scaler = StandardScaler()
    EiMG_scaled = scaler.fit_transform(data_i)
    sEMG_scaled = scaler.fit_transform(data_s)

    # EiMG
    clusters, model = perform_clustering(EiMG_scaled, n_clusters=2)
    pca = PCA(n_components=2)
    pca_data = pca.fit_transform(EiMG_scaled)
    tsne_data = TSNE(perplexity=50, random_state=42).fit_transform(EiMG_scaled)
    save_results(EiMG_scaled, clusters, model, meta_i, pca_data, tsne_data, pca)
    #sEMG
    clusters, model = perform_clustering(sEMG_scaled, n_clusters=2)
    pca = PCA(n_components=2)
    pca_data = pca.fit_transform(sEMG_scaled)
    tsne_data = TSNE(perplexity=50, random_state=42).fit_transform(sEMG_scaled)
    save_results(sEMG_scaled, clusters, model, meta_s, pca_data, tsne_data, pca)


    '''---------------------------Correlation-----------------------------'''
    # read data
    data_i, data_s = load_and_concatenate_emg_csv(dates, state, data_path)
    '''-------------------Time Domain------------------'''
    print("Results：")
    compute_corr(data_i, data_s)

    '''-----------------Frequency Domain-----------------'''
    segments_i = segment_signal(data_i)
    segments_s = segment_signal(data_s)

    freq, fft_i = compute_fft_segments(segments_i)
    _, fft_s = compute_fft_segments(segments_s)

    # Spearman
    corr_spearman = compute_correlation_heatmap(fft_i, fft_s, method='spearman')
    plot_heatmap(corr_spearman, freq, state, save_path, title='Spearman Correlation Heatmap')  # Use this function to draw heatmap

    # Kendall
    corr_kendall = compute_correlation_heatmap(fft_i, fft_s, method='kendall')
    plot_heatmap(corr_kendall, freq, state, save_path, title='Kendall Correlation Heatmap')

    '''---------------Features Domain--------------'''
    features_i = pd.read_excel(path_i)
    features_s = pd.read_excel(path_s)
    compute_matching_feature_correlation(features_i, features_s, method='spearman', feature_names=feature_names)
