"""
4_FeaturesExtraction.py: To extract all 40 selected features. The "i" and "s" in the code generally refer to "EiMG" and "sEMG"
15285
2025/7/30
"""
import os
import pandas as pd
from scipy.signal import welch
from statsmodels.tsa.ar_model import AutoReg
import antropy as ant
from scipy.integrate import simpson
import numpy as np
from scipy.signal import butter, filtfilt


def load_and_concatenate_emg_csv(date_list, state, base_path):
    all_EiMG_filtered = []
    all_sEMG_filtered = []

    for date in date_list:
        preprocessed_csv = os.path.join(base_path, f'EMG_Preprocessed_{date}_{state}.csv')
        df = pd.read_csv(preprocessed_csv)
        data_i = df[df['Type'] == 'EiMG'].sort_values('Index')['Value'].values
        data_s = df[df['Type'] == 'sEMG'].sort_values('Index')['Value'].values

        all_EiMG_filtered.append(data_i)
        all_sEMG_filtered.append(data_s)

    if len(all_EiMG_filtered) == 0 or len(all_sEMG_filtered) == 0:
        print("no valid data, return empty array")
        return np.array([]), np.array([])

    concatenated_i = np.concatenate(all_EiMG_filtered, axis=0)
    concatenated_s = np.concatenate(all_sEMG_filtered, axis=0)

    print("EiMG shape:", concatenated_i.shape)
    print("sEMG shape:", concatenated_s.shape)

    return concatenated_i, concatenated_s


def calculate_mmav1(signal):
    n = len(signal)
    weights = np.zeros(n)
    for i in range(n):
        if i < 0.25 * n:
            weights[i] = 4 * i / n
        elif i <= 0.75 * n:
            weights[i] = 1.0
        else:
            weights[i] = 4 * (n - i) / n
    mmav1 = np.sum(weights * np.abs(signal)) / n
    return mmav1


def calculate_mmav2(signal):
    n = len(signal)
    # 生成汉宁窗权重
    weights = 0.5 * (1 - np.cos(2 * np.pi * np.arange(n) / (n - 1)))
    mmav2 = np.sum(weights * np.abs(signal)) / n
    return mmav2


def basic_time_features(signal):
    afb = np.max(signal) - np.min(signal)
    mav = np.mean(np.abs(signal))
    mav1 = calculate_mmav1(signal)
    mav2 = calculate_mmav2(signal)
    # mav_slope = np.mean(np.diff(mav))
    rms = np.sqrt(np.mean(signal ** 2))
    var = np.var(signal)
    dvar = np.var(np.diff(signal))
    s = np.mean((signal - np.mean(signal)) ** 3) / (np.std(signal) ** 3)
    k = np.mean((signal - np.mean(signal)) ** 4) / (np.std(signal) ** 4)
    return np.array([afb, mav, mav1, mav2, rms, var, dvar, s, k]).reshape(1, -1)  # 9，AFB第一次爆发的振幅, MAV平均绝对值, MAV1修改后的平均绝对值1, MAV2修改后的平均绝对值2, MAVS平均绝对值斜率,
                                                                                                # RMS均方根, VAR方差, DVARV差分后的方差， SKEW偏度, KURT峰度


def frequency_features(signal, fs):  # 5
    freqs, psd = welch(signal, fs=fs)
    total_power = np.sum(psd)
    mean_freq = np.sum(freqs * psd) / total_power
    median_freq = freqs[np.cumsum(psd) >= total_power/2][0]
    max_power = np.max(psd)
    peak_freq = freqs[np.argmax(psd)]

    return np.array([mean_freq, median_freq, peak_freq, total_power, max_power]).reshape(1, -1)  # 'MNF'平均频率, 'MDF'中位数频率, 'PKF'峰值频率, 'TTP'总功率, 'MXP'


def entropy_features(signal):  # 2
    signal = np.asarray(signal, dtype=np.float64).flatten()

    r = 0.2 * np.std(signal)

    sam_en = ant.sample_entropy(
        signal,
        order=2,
        tolerance=r,
        metric="chebyshev"
    )

    ap_en = ant.app_entropy(signal)
    return np.array([ap_en, sam_en]).reshape(1, -1)  # 'ApEn', 'SampEn'


def complexity_features(signal, kmax=10):  # 3
    # 强制信号为一维数组并检查长度
    signal = np.asarray(signal, dtype=np.float64).flatten()
    if len(signal) < 2 * kmax:
        kmax = max(2, len(signal) // 2)

    # 使用位置参数代替关键字参数（关键修复）
    hg = ant.higuchi_fd(signal, kmax)

    katz = ant.katz_fd(signal)
    bc = ant.petrosian_fd(signal)
    return np.array([hg, katz, bc]).reshape(1, -1)  # 'HG', 'KATZ', 'BC'


def dynamic_features(signal, lags=4):
    ar_model = AutoReg(signal, lags=lags).fit()
    ar_params = ar_model.params[1:]
    dar = np.diff(ar_params)
    return np.concatenate([ar_params, dar]).reshape(1, -1)  # 'AR1', 'AR2', 'AR3', 'AR4', 'DAR1', 'DAR2', 'DAR3'


def waveform_features(signal):  # 3
    ssc = np.sum(np.diff(np.sign(np.diff(signal))) != 0)
    zc = np.sum(np.diff(np.sign(signal)) != 0)
    wl = np.sum(np.abs(np.diff(signal)))
    return np.array([ssc, zc, wl]).reshape(1, -1)  # 'SSC', 'ZC', 'WL'波形长度


def spectral_features(signal, fs, n_moments=[0, 2, 4]):  # SM
    spectrum = np.fft.fft(signal)
    n = len(signal)
    freqs = np.fft.fftfreq(n, 1 / fs)

    positive_mask = freqs >= 0
    freqs_pos = freqs[positive_mask]
    spectrum_pos = spectrum[positive_mask]

    psd = (np.abs(spectrum_pos) ** 2) / (fs * n)

    centroid = np.sum(freqs_pos * psd) / np.sum(psd)

    moments = []
    for n in n_moments:
        moment = simpson(y=(2 * np.pi * freqs_pos) ** n * psd, x=freqs_pos)
        moments.append(moment)

    return np.concatenate([[centroid], moments]).reshape(1, -1)


def differencing_features(signal):  # 2
    diff = np.diff(signal)
    damv = np.mean(np.abs(diff))
    dasdv = np.std(np.abs(diff))
    return np.array([damv, dasdv]).reshape(1, -1)


def max_to_min_power_density_ratio(signal, fs):  # 1
    freqs, psd = welch(signal, fs=fs)
    return np.array([np.max(psd)/np.min(psd)]).reshape(1, -1)  # 'DPR'


def VCF(signal, center_freqs):
    freqs = np.fft.fftfreq(len(signal))
    fft_values = np.fft.fft(signal)
    power_spectrum = np.abs(fft_values) ** 2
    center_freq = np.sum(freqs * power_spectrum) / np.sum(power_spectrum)
    center_freqs.append(center_freq)

    variance_center_freq = np.var(center_freqs)
    vcf = variance_center_freq
    return np.array(vcf), center_freqs  # VCF


class VCFCalculator:
    def __init__(self):
        self.center_freqs = []
    def __call__(self, signal):
        freqs = np.fft.fftfreq(len(signal))
        fft_val = np.abs(np.fft.fft(signal)) ** 2
        cf = np.sum(freqs * fft_val) / np.sum(fft_val)
        self.center_freqs.append(cf)
        return np.array([np.var(self.center_freqs)]).reshape(1, -1)


vcf_calculator = VCFCalculator()


def VFD(signal, max_scale=10, eps=1e-10):
    signal = np.asarray(signal, dtype=np.float64).flatten()
    if len(signal) < 10:
        return np.nan

    max_scale = min(max_scale, len(signal) // 2)
    scales = np.arange(2, max_scale + 1)

    if len(scales) < 2:
        return np.nan

    vars = []
    for s in scales:
        if s >= len(signal):
            break
        window_vars = [np.var(signal[i:i + s]) for i in range(len(signal) - s)]
        window_vars = [v + eps if v <= 0 else v for v in window_vars]
        vars.append(np.mean(window_vars))

    if len(vars) < 2:
        return np.nan

    log_scales = np.log(scales[:len(vars)])
    log_vars = np.log(vars)
    coeffs = np.polyfit(log_scales, log_vars, 1)
    return -coeffs[0]   # ‘VDF'


def calculate_snr_smar(signal, fs, signal_band=[0.5, 40], noise_band=[40, 100],  # SNR, SMAR
                       artefact_band=[0.1, 5], motion_threshold=3.0):

    def bandpass_filter(data, lowcut, highcut, fs, order=4):
        nyq = 0.5 * fs
        low = lowcut / nyq
        high = highcut / nyq
        b, a = butter(order, [low, high], btype='band')
        return filtfilt(b, a, data)

    sig_clean = bandpass_filter(signal, *signal_band, fs)
    noise = bandpass_filter(signal, *noise_band, fs)
    artefact = bandpass_filter(signal, *artefact_band, fs)

    signal_power = np.mean(sig_clean ** 2)
    noise_power = np.mean(noise ** 2)
    artefact_power = np.mean(artefact ** 2)

    moving_mask = (artefact > motion_threshold * np.std(artefact)) | \
                  (artefact < -motion_threshold * np.std(artefact))
    moving_artefact = artefact[moving_mask]

    if len(moving_artefact) > 0:
        adjusted_artefact_power = np.mean(moving_artefact ** 2)
    else:
        adjusted_artefact_power = artefact_power

    snr_db = 10 * np.log10(signal_power / noise_power)
    smar_db = 10 * np.log10(signal_power / adjusted_artefact_power)

    return np.array([snr_db, smar_db]).reshape(1, -1)


def extract_all_features(signal, fs, window_size=512, step_size=256):
    num_windows = (len(signal) - window_size) // step_size + 1
    features = []

    for i in range(num_windows):
        window = np.array(signal[i * step_size: i * step_size + window_size])

        # extract all features
        feat = np.hstack([
            basic_time_features(window),
            frequency_features(window, fs),
            entropy_features(window),
            complexity_features(window),
            dynamic_features(window),
            waveform_features(window),
            spectral_features(window, fs),
            differencing_features(window),
            max_to_min_power_density_ratio(window, fs),
            vcf_calculator(window),
            VFD(window).reshape(1, -1),
            calculate_snr_smar(window, fs, signal_band=[0.5, 40], noise_band=[40, 100],
                       artefact_band=[0.1, 5], motion_threshold=3.0)
        ])

        features.append(feat)

    features_array = np.vstack(features)
    return features_array

fs = 256
dates = ['Day 1', 'Day 2', 'Day 3']
statew = 'Walk'
states = 'Stand'
state = statew
data_path = r'data_after_mvc_path'
save_path = r'your save path for features'

feature_names = ['AFB', 'MAV', 'MAV(1)', 'MAV(2)', 'RMS', 'VAR', 'DAVR', 'SKEW', 'KURT', 'MNF', 'MDF', 'PKF', 'TTP', 'MXP', 'ApEn', 'SampEn', 'HG', 'KATZ', 'BC', 'AR(1)',
                 'AR(2)', 'AR(3)', 'AR(4)', 'DAR(1)', 'DAR(2)', 'DAR(3)', 'SSC', 'ZC', 'WL', 'SC', 'SM(1)', 'SM(2)', 'SM(3)', 'DAMV', 'DASDV', 'DPR', 'VCF', 'VFD', 'SNR', 'SMAR']

if __name__ == '__main__':

    all_EiMG, all_sEMG = load_and_concatenate_emg_csv(dates, state, data_path)

    features_i = extract_all_features(all_EiMG, fs)
    features_s = extract_all_features(all_sEMG, fs)
    df_i = pd.DataFrame(features_i, columns=feature_names)
    df_s = pd.DataFrame(features_s, columns=feature_names)

    # save
    save_path = os.path.join(save_path, f'features_{state}_i.xlsx')
    df_i.to_excel(save_path, index=False, engine='openpyxl')
    print(f'saved to {save_path}')

    save_path = os.path.join(save_path, f'features_{state}_s.xlsx')
    df_s.to_excel(save_path, index=False, engine='openpyxl')
    print(f'saved to {save_path}')